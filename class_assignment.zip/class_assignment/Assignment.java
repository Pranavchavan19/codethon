
package class_assignment;

import java.time.LocalDate;


public class Assignment {
    
  public void  title(String s)
  {
      System.out.println("Name of Assignment : "+s);
 
  }
  public void  date()
  {
        LocalDate today = LocalDate.now();
         System.out.println(today);
 
  }
    public void  description(String s2)
  {
      System.out.println("Description of Assignment : "+s2);
 
  }
      public void  Assignee(String s3)
  {
      System.out.println("Name of Student who did Assignment : "+s3);
 
  }
}
