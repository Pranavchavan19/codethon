package class_assignment;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
//package newiotest.neoysest;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class Assignment_Manager extends Student {

    public static void main(String[] args) {
        while (true) {
            System.out.println("1->   Create Assignment : ");
            System.out.println("2->   Add Assigment to collection : ");
            System.out.println("3->   show Assignment : ");
            System.out.println("4->   save assignment to file : ");
            System.out.println("5->   load assignment to file : ");
            System.out.println("6->   Check  Assignment on the basis of time : ");
            System.out.println("7->   Check   Student Details : ");
            System.out.println("8->   Check   trainee Details : ");
            System.out.println("Choose Your option ----->");
            Scanner sc = new Scanner(System.in);
            Scanner sc1 = new Scanner(System.in);
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("**************************************************************");

                    System.out.println("   Create Assignment : ");
                    Scanner g = new Scanner(System.in);
                    System.out.println("Enter Assignment ");
                    String d = g.nextLine();
                    Assignment t = new Assignment();
                    t.title(d);
                    // System.out.println(title);
                    t.description("Trainee have to write  code on the bais of " + d);
                    System.out.println("Date on which Assignment is created");
                    t.date();
                    t.Assignee(" Pranav Bappa Chavan");
                    System.out.println("**************************************************************");
                    break;
                case 2:
                    System.out.println("**************************************************************");

                    System.out.println("   Add Assigment to collection : ");
                    System.out.println("Add new Assignment for trainee");
                    Scanner sr = new Scanner(System.in);
                    String w = sr.nextLine();
                    System.out.println("Added assignment ----> " + w);
                    System.out.println("Added assignment on date --->");
                    Assignment rt = new Assignment();
                    rt.date();

                    List lst = new ArrayList();
                    System.out.println("show Assignment");
                    lst.add("Assignment On Exception handeling");
                    lst.add(w);
                    System.out.println(lst);
                    for (Object sj : lst) {

                        System.out.println(sj);
                    }
                    System.out.println("**************************************************************");
                    break;
                case 3:
                    System.out.println("**************************************************************");
                    System.out.println("show total assignment which is given to student");
                    System.out.println("previous assingent add first");
                    Scanner sr1 = new Scanner(System.in);
                    String w1 = sr1.nextLine();
                    System.out.println("Added previous assignment ----> " + w1);

                    List lst1 = new ArrayList();
                    System.out.println("show Assignment");
                    lst1.add("Assignment On Exception handeling");
                    lst1.add(w1);
                    System.out.println("All assignment given to student--->  ");
                    for (Object sj : lst1) {

                        System.out.println(sj);
                    }
                    System.out.println("**************************************************************");

                    break;

                case 4:
                    System.out.println("**************************************************************");

                    System.out.println("   save assignment to file : ");
                    System.out.println("File Saved Successfully --->");
                    try {
                        Path p = Paths.get("C:\\Users\\91766\\Desktop\\pranav.txt");
//            Path p1=Files.createDirectories(p);
                        Path p1 = Files.createFile(p);
                        System.out.println("File created");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:

                    System.out.println("   load assignment to file  successfully-----> ");
                    System.out.println("Content in file ----->");
                    try {
                        Path path = Paths.get("C:\\Users\\91766\\Desktop\\pranav.txt");
                        List<String> lstt = Files.readAllLines(path);
                        for (String str : lstt) {
                            System.out.println(str);
                        }
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println("**************************************************************");

                    //  System.out.println("**************************************************************");
                    break;
                case 6:
                    System.out.println("**************************************************************");

                    System.out.println("   Check  Assignment on the basis of time : ");
                    Assignment et = new Assignment();
                    System.out.println("first Assignment assigned on --->");

                    et.date();
                    System.out.println("Assignment name : Assignment On Exception handeling");
                    System.out.println("second Assignment assigned on --->");
                    System.out.println("2/11/2023");
                    // LocalDate today = LocalDate.now();
                    // System.out.println(today.getMonthValue());

                    System.out.println("Assignment name : file handleing");
                    System.out.println("**************************************************************");

                    break;
                case 7:
                    System.out.println("**************************************************************");

                    System.out.println("   Check   Student Details : ");
                    Student f = new Student();
                    f.stuName();
                    f.stuPRN();
                    System.out.println("**************************************************************");

                    break;
                case 8:
                    System.out.println("**************************************************************");

                    System.out.println("   Check   trainee Details : ");
                    trainer f1 = new trainer();
                    f1.trainerName();
                    System.out.println("**************************************************************");

                    break;
                default:

            }
        }

    }

}
