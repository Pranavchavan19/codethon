
package class_assignment;

import java.util.Scanner;


public class Student {
    public void stuName()
    {
        System.out.println("Enter Student Name : ");
        Scanner sc=new Scanner(System.in);
        String s1=sc.nextLine();
        System.out.println("name : "+s1);
    }
    
     public void stuPRN()
    {
        System.out.println("Enter Student PRN No : ");
        Scanner sc1=new Scanner(System.in);
        int c=sc1.nextInt();
        System.out.println("PRN N0 : "+c);

    }
    
}
