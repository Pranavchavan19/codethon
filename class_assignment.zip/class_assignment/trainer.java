
package class_assignment;

import java.util.Scanner;

public class trainer {
    public void trainerName()
    {
        System.out.println("Enter the name of trainer :");
        Scanner sw=new Scanner(System.in);
        String d=sw.nextLine();
        System.out.println(" Trainer name : "+d);

        
    }
    
}
